export interface institute{
    id:number;
    branch:string;
    city:string;
    contact:string
}