export interface course{
    id:number;
    course:string;
    duration:string;
    fees:number

}