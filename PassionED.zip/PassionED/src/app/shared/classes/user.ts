export interface user{
    id:number;
    user:string;
    password:string;
    contact:number
}