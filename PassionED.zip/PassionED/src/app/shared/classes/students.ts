export interface students{
    id:number;
    stdName:string;
    contact:number;
    stdEmail:string;
    specialization:any;
    collage: any;
    city: any
}